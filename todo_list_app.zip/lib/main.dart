import 'package:flutter/material.dart';
import 'package:todo_list_app/model/task.dart';
import 'package:todo_list_app/widgets/task_tile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Todo List',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Todo List'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Task> tasks = [];

  final TextEditingController _textEditingController =
      TextEditingController(text: null);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _textEditingController,
              decoration: const InputDecoration(
                  hintText: "Enter a task wording",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0)))),
            ),
            Expanded(
                child: tasks.isEmpty
                    ? const Center(child: Text("No task to display"))
                    : ListView.builder(
                        itemCount: tasks.length,
                        itemBuilder: (context, index) {
                          Task currentTask = tasks[index];
                          return TaskTile(
                            title: currentTask.title,
                            isDone: currentTask.isDone,
                            onChanged: (value) {
                              setState(() {
                                currentTask.isDone = value;
                                tasks[index] = currentTask;
                              });
                            },
                            onDelete: () {
                              setState(() {
                                tasks.removeAt(index);
                              });
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(SnackBar(
                                      duration: const Duration(seconds: 10),
                                      action: SnackBarAction(
                                          label: "Undo",
                                          onPressed: () {
                                            setState(() {
                                              tasks.insert(index, currentTask);
                                            });
                                          }),
                                      content: const Text("Task deleted")));
                            },
                          );
                        },
                      ))
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _createTask();
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _createTask() {
    if (_textEditingController.text.isEmpty) {
      return;
    }

    // Récuperer le texte saisi dans le textfield
    String taskTitle = _textEditingController.text;

    // Clear le textfield
    _textEditingController.clear();

    // Rafraichir l'affichage
    setState(() {
      // Ajouter la task à notre liste
      tasks.add(Task(title: taskTitle));
    });
  }
}
