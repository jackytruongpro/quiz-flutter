class Task {
  String title;
  bool isDone;

  Task({required this.title, this.isDone = false});
}

var task = Task(title: "My Task");
