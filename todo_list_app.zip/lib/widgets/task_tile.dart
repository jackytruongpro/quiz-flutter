import 'package:flutter/material.dart';

class TaskTile extends StatelessWidget {
  final String title;
  bool isDone;
  final void Function(bool) onChanged;
  final void Function() onDelete;

  TaskTile(
      {super.key,
      required this.title,
      required this.isDone,
      required this.onChanged,
      required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return ListTile(
        leading: Checkbox(
            value: isDone, onChanged: (value) => onChanged(value ?? false)),
        title: Text(title),
        trailing: IconButton(
          icon: const Icon(Icons.delete),
          onPressed: onDelete,
        ));
  }
}
